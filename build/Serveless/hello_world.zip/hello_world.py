def hello_world(arg):
    print("hello_world!",arg)